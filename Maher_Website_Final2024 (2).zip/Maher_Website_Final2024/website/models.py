from . import db
from flask_login import UserMixin
from sqlalchemy.sql import func
from sqlalchemy import desc
from flask_migrate import Migrate


class Rating(db.Model):
    rating_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    codingRating = db.Column(db.Integer, nullable=False)
    storyRating = db.Column(db.Integer, nullable=False)
    chatbotRating = db.Column(db.Integer, nullable=False)
    motionRating = db.Column(db.Integer, nullable=False)

    @classmethod
    def get_all_ratings(cls):
        return cls.query.all()


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True)
    password = db.Column(db.String(150))
    first_name = db.Column(db.String(150))
    last_name = db.Column(db.String(150))
    fail_count = db.Column(db.Integer, default=0)  # Add the fail_count column
    phone = db.Column(db.String(10))
    grade = db.Column(db.String(150))
    ratings = db.relationship('Rating')

    @classmethod
    def get_all_users(cls):
        return cls.query.all()

    @classmethod
    def get_highest_points_user(cls):
        highest_points_user = db.session.query(User.first_name, Levels.points).join(
            Levels).order_by(Levels.points.desc()).first()
        if highest_points_user:
            return highest_points_user
        else:
            return None

    @classmethod
    def get_second_highest_points_user(cls):
        highest_points_user = db.session.query(User.first_name, Levels.points).join(
            Levels).order_by(Levels.points.desc()).offset(1).first()
        if highest_points_user:
            return highest_points_user
        else:
            return None

    @classmethod
    def get_third_highest_points_user(cls):
        third_highest_points_user = db.session.query(User.first_name, Levels.points).join(
            Levels).order_by(Levels.points.desc()).offset(2).first()
        if third_highest_points_user:
            return third_highest_points_user
        else:
            return None

    @classmethod
    def get_fourth_highest_points_user(cls):
        fourth_highest_points_user = db.session.query(User.first_name, Levels.points).join(
            Levels).order_by(Levels.points.desc()).offset(3).first()
        if fourth_highest_points_user:
            return fourth_highest_points_user
        else:
            return None

    @classmethod
    def get_fifth_highest_points_user(cls):
        fifth_highest_points_user = db.session.query(User.first_name, Levels.points).join(
            Levels).order_by(Levels.points.desc()).offset(4).first()
        if fifth_highest_points_user:
            return fifth_highest_points_user
        else:
            return None


class Levels(db.Model):
    level_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    points = db.Column(db.Integer, default=0)
    level = db.Column(db.Integer, default=0)

    @classmethod
    def get_all_levels(cls):
        return cls.query.all()
