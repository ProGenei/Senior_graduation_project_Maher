from flask import request, jsonify, make_response
from flask import Blueprint, render_template, request, flash, jsonify, redirect, url_for, current_app
from flask_login import login_required, current_user
from .models import Rating, User, Levels
from . import db, mysql
from django.shortcuts import render
from flask_login import login_user, logout_user
import json
import ast

views = Blueprint('views', __name__)

@views.route('/', methods=['GET', 'POST'])
@views.route('/first', methods=['GET', 'POST'])
@login_required
def first():
    return render_template("first.html")


@views.route("/education")
def education():
    return render_template("education.html")


@views.route("/edu1")
def edu1():
    return render_template("edu1.html")


@views.route("/home")
def home():
    return render_template("home.html")


@views.route("/startWelcome")
@login_required
def startWelcome():
    first_name = current_user.first_name
    user_id = current_user.id
    level = Levels.query.filter_by(user_id=user_id).first()

    if not level:
        # If the user doesn't have a level yet, create a new one
        level = Levels(user_id=user_id, level=0, points=0)
        db.session.add(level)
        db.session.commit()

    return render_template("startWelcome.html", first_name=first_name, level=level)


@views.route("/recommend")
def recommend():
    # Assuming you have a way to get the current user's ID
    user_id = current_user.id

    # Query the ratings for the current user
    user_ratings = Rating.query.filter_by(user_id=user_id).first()

    # Sort the ratings in descending order
    sorted_ratings = sorted([
        ('البرمجة التفاعلية', user_ratings.codingRating),
        ('تحديات القصة', user_ratings.storyRating),
        ('روبوتات الدردشة', user_ratings.chatbotRating),
        ('الفيديوهات', user_ratings.motionRating)
    ], key=lambda x: x[1], reverse=True)

    cookies = dict(request.cookies)
    dict_obj = ast.literal_eval(cookies['user'])

    print(dict_obj)

    if 'category' in dict_obj:
        if dict_obj['category'] == 'video':
            if dict_obj['lesson'] == '1':
                return redirect('/video')
            elif dict_obj['lesson'] == '2':
                return redirect('/video2')
            elif dict_obj['lesson'] == '3':
                return redirect('/video3')
            elif dict_obj['lesson'] == '4':
                return redirect('/video4')
            elif dict_obj['lesson'] == '5':
                return redirect('/video5')

        elif dict_obj['category'] == 'interactive':
            if dict_obj['lesson'] == '1':
                return redirect('/interactive')
            if dict_obj['lesson'] == '2':
                return redirect('/interactivefive')

        elif dict_obj['category'] == 'story':
            if dict_obj['lesson'] == '1':
                return redirect('/storytelling1')
            elif dict_obj['lesson'] == '2':
                return redirect('/storytelling2')
            elif dict_obj['lesson'] == '3':
                return redirect('/storytelling3')
            elif dict_obj['lesson'] == '4':
                return redirect('/storytelling4')

        elif dict_obj['category'] == 'chatbot':
            if dict_obj['lesson'] == '1':
                return redirect('/chatbot1')
            elif dict_obj['lesson'] == '2':
                return redirect('/chatbot2')
            elif dict_obj['lesson'] == '3':
                return redirect('/chatbot3')
            elif dict_obj['lesson'] == '4':
                return redirect('/chatbot4')
            elif dict_obj['lesson'] == '5':
                return redirect('/chatbot5')

    return render_template("recommend.html", sorted_ratings=sorted_ratings)


@views.route("/yourRankings")
def yourRankings():
    # Assuming you have a way to get the current user's ID
    user_id = current_user.id

    # Query the ratings for the current user
    user_ratings = Rating.query.filter_by(user_id=user_id).first()

    # Sort the ratings in descending order
    sorted_ratings = sorted([
        ('البرمجة التفاعلية', user_ratings.codingRating),
        ('تحديات القصة', user_ratings.storyRating),
        ('روبوتات الدردشة', user_ratings.chatbotRating),
        ('الفيديوهات', user_ratings.motionRating)
    ], key=lambda x: x[1], reverse=True)

    return render_template("yourRankings.html", sorted_ratings=sorted_ratings)


@views.route("/quizTest")
def quizTest():
    return render_template("quizTest.html")


@views.route("/interactiveCode")
def interactiveCode():
    return render_template("interactiveCode.html")


@views.route("/storyTelling")
def storyTelling():
    return render_template("storyTelling.html")


@views.route("/motionGraphics")
def motionGraphics():
    return render_template("motionGraphics.html")


@views.route("/chatbot")
def chatbot():
    return render_template("chatbot.html")


@views.route("/preferenceTest", methods=['GET', 'POST'])
def preferenceTest():
    return render_template("preferenceTest.html")


@views.route('/save-ratings', methods=['POST'])
def save_ratings():
    try:
        data = request.json
        coding_rating = data['codingRating']
        story_rating = data['storyRating']
        chatbot_rating = data['chatbotRating']
        motion_rating = data['motionRating']

        # Assuming you have a logged-in user and can get user_id from session
        user_id = current_user.id

        rating = Rating(
            user_id=user_id,
            codingRating=coding_rating,
            storyRating=story_rating,
            chatbotRating=chatbot_rating,
            motionRating=motion_rating
        )

        db.session.add(rating)
        db.session.commit()

        return jsonify({'message': 'Ratings saved successfully'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@views.route("/congrats")
def congrats():
    return render_template("congrats.html")


@views.route("/congratsFinish")
def congratsFinish():
    user_id = current_user.id
    level_entry = Levels.query.filter_by(user_id=user_id).first()
    if level_entry is not None:
        level_entry.points += 20
        level_entry.level += 2
        db.session.commit()

    response = make_response(render_template("congratsFinish.html"))
    # Set the cookie with user_id and something
    user_id = current_user.id
    cookie_value = "{'user_id':'" + str(user_id) + "'}"
    response.set_cookie('user', cookie_value)

    return response

@views.route("/congratsFinishInt")
def congratsFinishInt():
    user_id = current_user.id
    level_entry = Levels.query.filter_by(user_id=user_id).first()
    if level_entry is not None:
        level_entry.points += 50
        level_entry.level += 5
        db.session.commit()
    return render_template("congratsFinishInt.html")


@views.route("/congratsFinishStory")
def congratsFinishStory():
    user_id = current_user.id
    level_entry = Levels.query.filter_by(user_id=user_id).first()
    if level_entry is not None:
        level_entry.points += 25
        level_entry.level += 2.5
        db.session.commit()
    return render_template("congratsFinishStory.html")


@views.route("/users", methods=['GET'])
def users():
    user_id = current_user.id
    Users = User.get_all_users()
    return render_template("users.html", Users=Users)


@views.route("/ratingdb", methods=['GET'])
def ratingdb():
    Ratings = Rating.query.all()
    return render_template("ratingsDB.html", Ratings=Ratings)


@views.route("/levelsDB", methods=['GET'])
def levelsDB():
    levels = Levels.query.all()
    return render_template("levelsDB.html", levels=levels)


def highest_points_view(request):
    highest_user = Levels.get_highest_points_user()
    if highest_user:
        user_name, points = highest_user
        context = {
            'user_name': user_name,
            'points': points
        }
    else:
        context = {}

    return render(request, 'list.html', context)


@views.route("/list")
def list():
    highest_user = User.get_highest_points_user()
    second_highest_user = User.get_second_highest_points_user()
    third_highest_user = User.get_third_highest_points_user()
    fourth_highest_user = User.get_fourth_highest_points_user()
    fifth_highest_user = User.get_fifth_highest_points_user()

    context = {}

    if highest_user:
        user_name, points = highest_user
        context['user_name'] = user_name
        context['points'] = points

    if second_highest_user:
        user_name, points = second_highest_user
        context['second_highest_user_name'] = user_name
        context['second_highest_points'] = points

    if third_highest_user:
        user_name, points = third_highest_user
        context['third_highest_user_name'] = user_name
        context['third_highest_points'] = points

    if fourth_highest_user:
        user_name, points = fourth_highest_user
        context['fourth_highest_user_name'] = user_name
        context['fourth_highest_points'] = points

    if fifth_highest_user:
        user_name, points = fifth_highest_user
        context['fifth_highest_user_name'] = user_name
        context['fifth_highest_points'] = points

    return render_template("list.html", **context)


@views.route("/account", methods=['GET', 'POST'])
def account():
    if not current_user.is_authenticated:
        return redirect(url_for('auth.login'))
    user = User.query.get(current_user.id)
    if request.method == 'POST':
        user.first_name = request.form['first_name']
        user.email = request.form['email']
        user.last_name = request.form['last_name']
        user.phone = request.form['phone']
        user.grade = request.form['grade']

        db.session.commit()
        flash('Your account information has been updated.', 'success')
        return redirect(url_for('views.account'))

    return render_template("account.html", user=user)


@views.route("/myPage")
def myPage():
    user_id = current_user.id

    level = Levels.query.filter_by(user_id=user_id).first()
    level_entry = Levels.query.filter_by(user_id=user_id).first()

    if level_entry is not None:
        if level_entry.points >= 100:
            itemSucss1 = 'مبروك! لقد حصلت على 100 نقطة'
        else:
            itemSucss1 = ''
    if level_entry is not None:
        if level_entry.level >= 10:
            itemSucss2 = 'مبروك! لقد تجاوزت 10 مراحل'
        else:
            itemSucss2 = ''

    if level_entry is not None:
        if level_entry.level >= 5:
            level_text = 'متقدم'
        elif level_entry.level == 5:
            level_text = 'متوسط'
        elif level_entry.level < 5:
            level_text = 'مبتديْ'
        else:
            level_text = 'لقد وصلت للمرحلة المبتدئة'
    return render_template("myPage.html", points=level.points, level=level.level, itemSucss1=itemSucss1, itemSucss2=itemSucss2, level_text=level_text)


@views.route("/M1_lesson1")
def M1_lesson1():
    return render_template("M1_lesson1.html")


@views.route("/M2_lesson1")
def M2_lesson1():
    return render_template("M2_lesson1.html")


@views.route('/image', methods=['GET', 'POST'])
def display_image():
    if request.method == 'GET':
        # Retrieve the questions from the database

        cur = mysql.connection.cursor()
        cur.execute(
            "SELECT id, image, question, ans FROM interactive_coding WHERE name = 'lesson 4'")
        questions = cur.fetchall()
        cur.close()
        return render_template('image.html', questions=questions)
    elif request.method == 'POST':
        # Check the answer and return the result
        user_answer = request.form['answer']
        correct_answer = request.form['correct_answer']
        if user_answer == correct_answer:
            return jsonify({'result': 'correct'})
        else:
            return jsonify({'result': 'incorrect', 'question': request.form['question']})


@views.route('/interactive', methods=['GET', 'POST'])
def display_images():
    if request.method == 'GET':
        # Retrieve the questions from the database
        cur = mysql.connection.cursor()
        cur.execute(
            "SELECT id, image, question, ans FROM interactive_coding WHERE name = 'lesson 4'")
        questions = cur.fetchall()
        cur.close()
        return render_template('interactive.html', questions=questions)
    elif request.method == 'POST':
        # Check the answer and return the result
        user_answer = request.form['answer']
        correct_answer = request.form['correct_answer']
        if user_answer == correct_answer:
            return jsonify({'result': 'correct'})
        else:
            return jsonify({'result': 'incorrect', 'question': request.form['question']})


@views.route('/video', methods=['GET'])
def video():
    cur = mysql.connection.cursor()
    cur.execute('SELECT video_link FROM videos where name = "lesson 1"')
    storiesDetails = cur.fetchall()
    cur.close()
    return render_template('video.html', storiesDetails=storiesDetails)


@views.route('/QM2_lesson1', methods=['GET'])
def QM2_lesson1():
    return render_template('QM2_lesson1.html')


@views.route('/video2', methods=['GET'])
def video2():
    cur = mysql.connection.cursor()
    cur.execute('SELECT video_link FROM videos where name = "lesson 2"')
    storiesDetails = cur.fetchall()
    cur.close()
    user_id = current_user.id
    level_entry = Levels.query.filter_by(user_id=user_id).first()
    if level_entry is not None:
        level_entry.points += 20
        level_entry.level += 2
        db.session.commit()
    return render_template('video2.html', storiesDetails=storiesDetails)


@views.route('/videotest2', methods=['GET'])
def videotest2():
    return render_template('QM2_lesson2.html')


@views.route('/video3', methods=['GET'])
def video3():
    cur = mysql.connection.cursor()
    cur.execute('SELECT video_link FROM videos where name = "lesson 3"')
    storiesDetails = cur.fetchall()
    cur.close()
    user_id = current_user.id
    level_entry = Levels.query.filter_by(user_id=user_id).first()
    if level_entry is not None:
        level_entry.points += 20
        level_entry.level += 2
        db.session.commit()
    return render_template('video3.html', storiesDetails=storiesDetails)


@views.route('/videotest3', methods=['GET'])
def videotest3():
    return render_template('QM2_lesson3.html')


@views.route('/video4', methods=['GET'])
def video4():
    cur = mysql.connection.cursor()
    cur.execute('SELECT video_link FROM videos where name = "lesson 4"')
    storiesDetails = cur.fetchall()
    cur.close()
    user_id = current_user.id
    level_entry = Levels.query.filter_by(user_id=user_id).first()
    if level_entry is not None:
        level_entry.points += 20
        level_entry.level += 2
        db.session.commit()
    return render_template('video4.html', storiesDetails=storiesDetails)


@views.route('/videotest4', methods=['GET'])
def videotest4():
    return render_template('QM2_lesson4.html')


@views.route('/video5', methods=['GET'])
def video5():
    cur = mysql.connection.cursor()
    cur.execute('SELECT video_link FROM videos where name = "lesson 5"')
    storiesDetails = cur.fetchall()
    cur.close()
    user_id = current_user.id
    level_entry = Levels.query.filter_by(user_id=user_id).first()
    if level_entry is not None:
        level_entry.points += 20
        level_entry.level += 2
        db.session.commit()
    return render_template('video5.html', storiesDetails=storiesDetails)


@views.route('/videotest5', methods=['GET'])
def videotest5():
    return render_template('QM2_lesson5.html')


@views.route('/doneMssg', methods=['GET'])
def doneMssg():
    return render_template('doneMssg.html')


@views.route('/storyas', methods=['GET'])
def storyas():
    cur = mysql.connection.cursor()
    cur.execute('SELECT image FROM stories where name = "lesson 1"')
    storiesDetails = cur.fetchall()
    cur.close()
    return render_template('storyas.html', storiesDetails=storiesDetails)


@views.route('/lesson1', methods=['GET'])
def lesson1():
    cur = mysql.connection.cursor()
    cur.execute('SELECT image FROM lessons where name = "lesson 1"')
    storiesDetails = cur.fetchall()
    cur.close()
    return render_template('lesson1.html', storiesDetails=storiesDetails)


@views.route('/storytelling1', methods=['GET'])
def storytelling1():
    cur = mysql.connection.cursor()
    cur.execute('SELECT image FROM stories where name = "lesson 1"')
    storiesDetails = cur.fetchall()
    cur.close()
    user_id = current_user.id
    return render_template('storytelling1.html', storiesDetails=storiesDetails)


@views.route('/storytest')
def storytest():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes where name = "lesson 1"')
    questions = cur.fetchall()
    cur.close()

    return render_template('storytest.html', questions=questions)


@views.route('/storytelling2', methods=['GET'])
def storytelling2():
    cur = mysql.connection.cursor()
    cur.execute('SELECT image FROM stories where name = "lesson 2"')
    storiesDetails = cur.fetchall()
    cur.close()
    user_id = current_user.id
    level_entry = Levels.query.filter_by(user_id=user_id).first()
    if level_entry is not None:
        level_entry.points += 25
        level_entry.level += 2.5
        db.session.commit()
    return render_template('storytelling2.html', storiesDetails=storiesDetails)


@views.route('/storytest2')
def storytest2():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes where name = "lesson 2"')
    questions = cur.fetchall()
    cur.close()

    return render_template('storytest2.html', questions=questions)


@views.route('/storytelling3', methods=['GET'])
def storytelling3():
    cur = mysql.connection.cursor()
    cur.execute('SELECT image FROM stories where name = "lesson 3"')
    storiesDetails = cur.fetchall()
    cur.close()
    user_id = current_user.id
    level_entry = Levels.query.filter_by(user_id=user_id).first()
    if level_entry is not None:
        level_entry.points += 25
        level_entry.level += 2.5
        db.session.commit()
    return render_template('storytelling3.html', storiesDetails=storiesDetails)


@views.route('/storytest3')
def storytest3():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes where name = "lesson 3"')
    questions = cur.fetchall()
    cur.close()

    return render_template('storytest3.html', questions=questions)


@views.route('/storytelling4', methods=['GET'])
def storytelling4():
    cur = mysql.connection.cursor()
    cur.execute('SELECT image FROM stories where name = "lesson 4"')
    storiesDetails = cur.fetchall()
    cur.close()
    user_id = current_user.id
    level_entry = Levels.query.filter_by(user_id=user_id).first()
    if level_entry is not None:
        level_entry.points += 25
        level_entry.level += 2.5
        db.session.commit()
    return render_template('storytelling4.html', storiesDetails=storiesDetails)


@views.route('/storytest4')
def storytest4():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes where name = "lesson 4"')
    questions = cur.fetchall()
    cur.close()

    return render_template('storytest4.html', questions=questions)


@views.route('/interactivefive', methods=['GET', 'POST'])
def interactivefive():
    if request.method == 'GET':
        # Retrieve the questions from the database
        cur = mysql.connection.cursor()
        cur.execute(
            "SELECT id, image, question, ans FROM interactive_coding WHERE name = 'lesson 5'")
        questions = cur.fetchall()
        cur.close()
        user_id = current_user.id
        level_entry = Levels.query.filter_by(user_id=user_id).first()
        if level_entry is not None:
            level_entry.points += 50
            level_entry.level += 5
            db.session.commit()
        return render_template('interactivefive.html', questions=questions)
    elif request.method == 'POST':
        # Check the answer and return the result
        user_answer = request.form['answer']
        correct_answer = request.form['correct_answer']
        if user_answer == correct_answer:
            return jsonify({'result': 'correct'})
        else:
            return jsonify({'result': 'incorrect', 'question': request.form['question']})


# Home route
@views.route('/chatbot1')
def chatbot1():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM chatbot where lesson_name = "lesson 1"')
    questions = cur.fetchall()
    cur.close()

    user_id = current_user.id

    return render_template('chatbot1.html', questions=questions)


@views.route('/chatbot2')
def chatbot2():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM chatbot where lesson_name = "lesson 2"')
    questions = cur.fetchall()
    cur.close()
    user_id = current_user.id
    level_entry = Levels.query.filter_by(user_id=user_id).first()
    if level_entry is not None:
        level_entry.points += 20
        level_entry.level += 2
        db.session.commit()
    return render_template('chatbot2.html', questions=questions)


@views.route('/chatbot3')
def chatbot3():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM chatbot where lesson_name = "lesson 3"')
    questions = cur.fetchall()
    cur.close()
    user_id = current_user.id
    level_entry = Levels.query.filter_by(user_id=user_id).first()
    if level_entry is not None:
        level_entry.points += 20
        level_entry.level += 2
        db.session.commit()
    return render_template('chatbot3.html', questions=questions)


@views.route('/chatbot4')
def chatbot4():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM chatbot where lesson_name = "lesson 4"')
    questions = cur.fetchall()
    cur.close()
    user_id = current_user.id
    level_entry = Levels.query.filter_by(user_id=user_id).first()
    if level_entry is not None:
        level_entry.points += 20
        level_entry.level += 2
        db.session.commit()
    return render_template('chatbot4.html', questions=questions)


@views.route('/chatbot5')
def chatbot5():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM chatbot where lesson_name = "lesson 5"')
    questions = cur.fetchall()
    cur.close()
    user_id = current_user.id
    level_entry = Levels.query.filter_by(user_id=user_id).first()
    if level_entry is not None:
        level_entry.points += 20
        level_entry.level += 2
        db.session.commit()
    return render_template('chatbot5.html', questions=questions)


# Submit route
@views.route('/submit_chat', methods=['POST'])
def submit_chat():
    answer = request.form['answer']  # Get the user's answer from the form
    # Get the question ID from the form
    question_id = int(request.form['question_id'])

    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT ans FROM chatbot WHERE id = %s', (question_id,))
    correct_answer = cur.fetchone()[0]
    cur.close()

    if answer == correct_answer:
        result = "Correct!"
    else:
        result = "Invalid!"

    return render_template('result.html', result=result)


# Home route
@views.route('/quiz')
def quiz():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes WHERE name = "lesson 1"')
    questions = cur.fetchall()
    cur.close()

    return render_template('quiz.html', questions=questions)

# Home route


@views.route('/quizchatbot')
def quizchatbot():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes WHERE name = "lesson 1"')
    questions = cur.fetchall()
    cur.close()

    return render_template('quizchatbot.html', questions=questions)

# Home route


@views.route('/quizstory')
def quizstory():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes WHERE name = "lesson 1"')
    questions = cur.fetchall()
    cur.close()

    return render_template('quizstory.html', questions=questions)


@views.route('/quiz2')
def quiz2():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes WHERE name = "lesson 2"')
    questions = cur.fetchall()
    cur.close()

    return render_template('quiz2.html', questions=questions)


@views.route('/quiz2chatbot')
def quiz2chatbot():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes WHERE name = "lesson 2"')
    questions = cur.fetchall()
    cur.close()

    return render_template('quiz2chatbot.html', questions=questions)


@views.route('/quiz2story')
def quiz2story():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes WHERE name = "lesson 2"')
    questions = cur.fetchall()
    cur.close()

    return render_template('quiz2story.html', questions=questions)


@views.route('/quiz3')
def quiz3():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes WHERE name = "lesson 3"')
    questions = cur.fetchall()
    cur.close()

    return render_template('quiz3.html', questions=questions)


@views.route('/quiz3chatbot')
def quiz3chatbot():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes WHERE name = "lesson 3"')
    questions = cur.fetchall()
    cur.close()

    return render_template('quiz3chatbot.html', questions=questions)


@views.route('/quiz3story')
def quiz3story():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes WHERE name = "lesson 3"')
    questions = cur.fetchall()
    cur.close()

    return render_template('quiz3story.html', questions=questions)


@views.route('/quiz4')
def quiz4():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes WHERE name = "lesson 4"')
    questions = cur.fetchall()
    cur.close()

    return render_template('quiz4.html', questions=questions)


@views.route('/quiz4chatbot')
def quiz4chatbot():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes WHERE name = "lesson 4"')
    questions = cur.fetchall()
    cur.close()

    return render_template('quiz4chatbot.html', questions=questions)


@views.route('/quiz4story')
def quiz4story():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes WHERE name = "lesson 4"')
    questions = cur.fetchall()
    cur.close()

    return render_template('quiz4story.html', questions=questions)


@views.route('/quiz4intr')
def quiz4intr():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes WHERE name = "lesson 4"')
    questions = cur.fetchall()
    cur.close()

    return render_template('quiz4intr.html', questions=questions)


@views.route('/quiz5')
def quiz5():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes WHERE name = "lesson 5"')
    questions = cur.fetchall()
    cur.close()

    return render_template('quiz5.html', questions=questions)


@views.route('/quiz5chatbot')
def quiz5chatbot():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes WHERE name = "lesson 5"')
    questions = cur.fetchall()
    cur.close()

    return render_template('quiz5chatbot.html', questions=questions)


@views.route('/quiz5intr')
def quiz5intr():
    # Access the database
    cur = mysql.connection.cursor()
    cur.execute('SELECT * FROM quizzes WHERE name = "lesson 5"')
    questions = cur.fetchall()
    cur.close()

    return render_template('quiz5intr.html', questions=questions)


@views.route('/specificVideo')
def specificVideo():
    lesson = request.args.get('lesson')

    if str(lesson) == '1':
        return redirect('/video')
    elif str(lesson) == '2':
        return redirect('/video2')
    elif str(lesson) == '3':
        return redirect('/video3')
    elif str(lesson) == '4':
        return redirect('/video4')
    elif str(lesson) == '5':
        return redirect('/video5')


@views.route('/specificIntr')
def specificIntr():
    lesson = request.args.get('lesson')

    if str(lesson) == '1':
        return redirect('/interactive')
    else:
        return redirect('/interactivefive')


@views.route('/specificStory')
def specificStory():
    lesson = request.args.get('lesson')

    if str(lesson) == '1':
        return redirect('/storytelling1')
    elif str(lesson) == '2':
        return redirect('/storytelling2')
    elif str(lesson) == '3':
        return redirect('/storytelling3')
    elif str(lesson) == '4':
        return redirect('/storytelling4')


@views.route('/specificChatbot')
def specificChatbot():
    lesson = request.args.get('lesson')

    if str(lesson) == '1':
        return redirect('/chatbot1')
    elif str(lesson) == '2':
        return redirect('/chatbot2')
    elif str(lesson) == '3':
        return redirect('/chatbot3')
    elif str(lesson) == '4':
        return redirect('/chatbot4')
    elif str(lesson) == '5':
        return redirect('/chatbot5')


@views.route('/submit', methods=['POST'])
def submit():
    lesson = request.form.get('lesson')
    category = request.form.get('category')

    print("lesson: ", lesson)
    print("category: ", category)

    cur = mysql.connection.cursor()
    score = 0
    total_questions = 0.00000001

    for key, value in request.form.items():
        if key.startswith('answer'):
            quiz_id = key.replace('answer', '')
            query = "SELECT ans FROM quizzes WHERE id = %s"
            cur.execute(query, (quiz_id,))
            correct_answer = cur.fetchone()[0]
            if value == correct_answer:
                score += 1
            total_questions += 1

    cur.close()

    rounded_percentage = (score / total_questions) * 100
    percentage = round(rounded_percentage)

    result = 'Passed' if percentage >= 75 else 'Failed'

    # Assuming you are using Flask-Login and current_user is available
    if percentage < 75:

        if current_user.fail_count is None:
            current_user.fail_count = 0

        print("fail_count before increment: ", current_user.fail_count)

        # Increment the fail_count
        current_user.fail_count += 1
        db.session.commit()

        print("fail_count after increment: ", current_user.fail_count)

        # Redirect based on the fail_count value
        if current_user.fail_count == 1:
            return redirect(f'/secondRank?lesson={lesson}')
        elif current_user.fail_count == 2:
            return redirect(f'/thirdRank?lesson={lesson}')
        elif current_user.fail_count >= 3:
            return redirect(f'/fourthRank?lesson={lesson}')

    if category == 'video':
        if lesson == '1':
            return f"<script>alert('Score: {percentage}% - {result}'); window.location='/video2'</script>"
        elif lesson == '2':
            return f"<script>alert('Score: {percentage}% - {result}'); window.location='/video3'</script>"
        elif lesson == '3':
            return f"<script>alert('Score: {percentage}% - {result}'); window.location='/video4'</script>"
        elif lesson == '4':
            return f"<script>alert('Score: {percentage}% - {result}'); window.location='/video5'</script>"
        elif lesson == '5':
            return f"<script>alert('Score: {percentage}% - {result}'); window.location='/congratsFinish'</script>"

    elif category == 'interactive':
        if lesson == '1':
            return f"<script>alert('Score: {percentage}% - {result}'); window.location='/interactivefive'</script>"
        elif lesson == '2':
            return f"<script>alert('Score: {percentage}% - {result}'); window.location='/congratsFinish'</script>"

    elif category == 'story':
        if lesson == '1':
            return f"<script>alert('Score: {percentage}% - {result}'); window.location='/storytelling2'</script>"
        elif lesson == '2':
            return f"<script>alert('Score: {percentage}% - {result}'); window.location='/storytelling3'</script>"
        elif lesson == '3':
            return f"<script>alert('Score: {percentage}% - {result}'); window.location='/storytelling4'</script>"
        elif lesson == '4':
            return f"<script>alert('Score: {percentage}% - {result}'); window.location='/congratsFinish'</script>"

    elif category == "chatbot":
        if lesson == '1':
            return f"<script>alert('Score: {percentage}% - {result}'); window.location='/chatbot2'</script>"
        elif lesson == '2':
            return f"<script>alert('Score: {percentage}% - {result}'); window.location='/chatbot3'</script>"
        elif lesson == '3':
            return f"<script>alert('Score: {percentage}% - {result}'); window.location='/chatbot4'</script>"
        elif lesson == '4':
            return f"<script>alert('Score: {percentage}% - {result}'); window.location='/chatbot5'</script>"
        elif lesson == '5':
            return f"<script>alert('Score: {percentage}% - {result}'); window.location='/congratsFinish'</script>"

    return f"<script>alert('Score: {percentage}% - {result}');'</script>"


@views.route('/secondRank')
def secondRank():
    # Assuming you have a way to get the current user's ID
    user_id = current_user.id

    # Query the ratings for the current user
    user_ratings = Rating.query.filter_by(user_id=user_id).first()

    # Sort the ratings in descending order
    sorted_ratings = sorted([
        ('البرمجة التفاعلية', user_ratings.codingRating),
        ('تحديات القصة', user_ratings.storyRating),
        ('روبوتات الدردشة', user_ratings.chatbotRating),
        ('الفيديوهات', user_ratings.motionRating)
    ], key=lambda x: x[1], reverse=True)

    return render_template('secondRank.html', sorted_ratings=sorted_ratings)


@views.route('/thirdRank')
def thirdRank():
    # Assuming you have a way to get the current user's ID
    user_id = current_user.id

    # Query the ratings for the current user
    user_ratings = Rating.query.filter_by(user_id=user_id).first()

    # Sort the ratings in descending order
    sorted_ratings = sorted([
        ('البرمجة التفاعلية', user_ratings.codingRating),
        ('تحديات القصة', user_ratings.storyRating),
        ('روبوتات الدردشة', user_ratings.chatbotRating),
        ('الفيديوهات', user_ratings.motionRating)
    ], key=lambda x: x[1], reverse=True)

    return render_template('thirdRank.html', sorted_ratings=sorted_ratings)


@views.route('/fourthRank')
def fourthRank():
    # Assuming you have a way to get the current user's ID
    user_id = current_user.id

    # Query the ratings for the current user
    user_ratings = Rating.query.filter_by(user_id=user_id).first()

    # Sort the ratings in descending order
    sorted_ratings = sorted([
        ('البرمجة التفاعلية', user_ratings.codingRating),
        ('تحديات القصة', user_ratings.storyRating),
        ('روبوتات الدردشة', user_ratings.chatbotRating),
        ('الفيديوهات', user_ratings.motionRating)
    ], key=lambda x: x[1], reverse=True)

    return render_template('fourthRank.html', sorted_ratings=sorted_ratings)


@views.route('/yourrankings')
def yourrankings():

    return render_template('yourrankings.html')


@views.route('/preferencetest')
def preferencetest():
    return render_template('preferencetest.html')


@views.route("/logout")
def logout():
    logout_user()
    return render_template("first.html")
